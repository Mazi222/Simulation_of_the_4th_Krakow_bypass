/****************************************************************************
** Meta object code from reading C++ file 'simulation_gui.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Simulation_of_the_4th_Krakow_bypass/Bypass_GUI/simulation_gui.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'simulation_gui.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Simulation_GUI_t {
    QByteArrayData data[6];
    char stringdata0[88];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Simulation_GUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Simulation_GUI_t qt_meta_stringdata_Simulation_GUI = {
    {
QT_MOC_LITERAL(0, 0, 14), // "Simulation_GUI"
QT_MOC_LITERAL(1, 15, 14), // "move_cars_beta"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 15), // "set_sum_of_cars"
QT_MOC_LITERAL(4, 47, 23), // "set_partial_sum_of_cars"
QT_MOC_LITERAL(5, 71, 16) // "set_flow_of_cars"

    },
    "Simulation_GUI\0move_cars_beta\0\0"
    "set_sum_of_cars\0set_partial_sum_of_cars\0"
    "set_flow_of_cars"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Simulation_GUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   34,    2, 0x0a /* Public */,
       3,    0,   35,    2, 0x0a /* Public */,
       4,    0,   36,    2, 0x0a /* Public */,
       5,    0,   37,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Simulation_GUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Simulation_GUI *_t = static_cast<Simulation_GUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->move_cars_beta(); break;
        case 1: _t->set_sum_of_cars(); break;
        case 2: _t->set_partial_sum_of_cars(); break;
        case 3: _t->set_flow_of_cars(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject Simulation_GUI::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_Simulation_GUI.data,
      qt_meta_data_Simulation_GUI,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Simulation_GUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Simulation_GUI::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Simulation_GUI.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsView::qt_metacast(_clname);
}

int Simulation_GUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
